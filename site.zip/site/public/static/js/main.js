// JavaScript principal pour le site NSI

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeMathJax();
    initializeCodeHighlighting();
    initializeScrollEffects();
    initializeTooltips();
});

// Navigation mobile
function initializeNavigation() {
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });
        
        // Fermer le menu en cliquant sur un lien
        const navLinks = navMenu.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navMenu.classList.remove('active');
                navToggle.classList.remove('active');
            });
        });
        
        // Fermer le menu en cliquant à l'extérieur
        document.addEventListener('click', function(event) {
            if (!navToggle.contains(event.target) && !navMenu.contains(event.target)) {
                navMenu.classList.remove('active');
                navToggle.classList.remove('active');
            }
        });
    }
}

// Configuration MathJax
function initializeMathJax() {
    if (window.MathJax) {
        MathJax.typesetPromise().then(() => {
            console.log('MathJax rendering complete');
        }).catch((err) => {
            console.error('MathJax rendering failed:', err);
        });
    }
}

// Coloration syntaxique du code
function initializeCodeHighlighting() {
    // Ajouter des numéros de ligne aux blocs de code
    const codeBlocks = document.querySelectorAll('pre code');
    codeBlocks.forEach(block => {
        const lines = block.textContent.split('\n');
        if (lines.length > 1) {
            block.classList.add('line-numbers');
        }
    });
    
    // Ajouter un bouton de copie aux blocs de code
    const preBlocks = document.querySelectorAll('pre');
    preBlocks.forEach(pre => {
        const copyButton = document.createElement('button');
        copyButton.className = 'copy-code-btn';
        copyButton.innerHTML = '<i class="fas fa-copy"></i>';
        copyButton.title = 'Copier le code';
        
        copyButton.addEventListener('click', function() {
            const code = pre.querySelector('code');
            if (code) {
                navigator.clipboard.writeText(code.textContent).then(() => {
                    copyButton.innerHTML = '<i class="fas fa-check"></i>';
                    copyButton.style.color = 'var(--success-color)';
                    
                    setTimeout(() => {
                        copyButton.innerHTML = '<i class="fas fa-copy"></i>';
                        copyButton.style.color = '';
                    }, 2000);
                }).catch(err => {
                    console.error('Erreur lors de la copie:', err);
                });
            }
        });
        
        pre.style.position = 'relative';
        pre.appendChild(copyButton);
    });
}

// Effets de défilement
function initializeScrollEffects() {
    // Animation des éléments au scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observer les cartes et sections
    const animatedElements = document.querySelectorAll(
        '.level-card, .chapter-card, .exercise-card, .feature-card, .file-card'
    );
    
    animatedElements.forEach(element => {
        element.classList.add('animate-on-scroll');
        observer.observe(element);
    });
    
    // Bouton retour en haut
    const scrollTopBtn = createScrollTopButton();
    
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('visible');
        } else {
            scrollTopBtn.classList.remove('visible');
        }
    });
}

// Créer le bouton de retour en haut
function createScrollTopButton() {
    const button = document.createElement('button');
    button.className = 'scroll-top-btn';
    button.innerHTML = '<i class="fas fa-arrow-up"></i>';
    button.title = 'Retour en haut';
    
    button.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    document.body.appendChild(button);
    return button;
}

// Tooltips
function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(event) {
    const element = event.target;
    const tooltipText = element.getAttribute('data-tooltip');
    
    if (!tooltipText) return;
    
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = tooltipText;
    
    document.body.appendChild(tooltip);
    
    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
    
    element._tooltip = tooltip;
}

function hideTooltip(event) {
    const element = event.target;
    if (element._tooltip) {
        document.body.removeChild(element._tooltip);
        element._tooltip = null;
    }
}

// Utilitaires pour les exercices
function filterExercises() {
    const difficultyFilter = document.getElementById('difficulty-filter');
    const typeFilter = document.getElementById('type-filter');
    const sortFilter = document.getElementById('sort-filter');
    
    if (!difficultyFilter || !typeFilter || !sortFilter) return;
    
    const exercises = document.querySelectorAll('.exercise-card');
    const exercisesArray = Array.from(exercises);
    
    // Filtrage
    exercisesArray.forEach(exercise => {
        const difficulty = exercise.dataset.difficulty;
        const type = exercise.dataset.type;
        
        const showDifficulty = difficultyFilter.value === 'all' || difficulty === difficultyFilter.value;
        const showType = typeFilter.value === 'all' || type === typeFilter.value;
        
        exercise.style.display = (showDifficulty && showType) ? 'block' : 'none';
    });
    
    // Tri
    const container = document.getElementById('exercises-container');
    if (container) {
        const visibleExercises = exercisesArray.filter(ex => ex.style.display !== 'none');
        
        visibleExercises.sort((a, b) => {
            const sortBy = sortFilter.value;
            
            switch (sortBy) {
                case 'difficulty':
                    const difficultyOrder = { 'easy': 1, 'medium': 2, 'hard': 3 };
                    return difficultyOrder[a.dataset.difficulty] - difficultyOrder[b.dataset.difficulty];
                    
                case 'recent':
                    // Tri par ordre inverse (plus récent en premier)
                    return b.dataset.order - a.dataset.order;
                    
                case 'name':
                default:
                    const titleA = a.querySelector('.exercise-title').textContent;
                    const titleB = b.querySelector('.exercise-title').textContent;
                    return titleA.localeCompare(titleB);
            }
        });
        
        // Réorganiser les éléments
        visibleExercises.forEach(exercise => {
            container.appendChild(exercise);
        });
    }
}

// Recherche en temps réel
function initializeSearch() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;
    
    let searchTimeout;
    
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            performSearch(this.value);
        }, 300);
    });
}

function performSearch(query) {
    const searchableElements = document.querySelectorAll('.searchable');
    const normalizedQuery = query.toLowerCase().trim();
    
    if (normalizedQuery === '') {
        searchableElements.forEach(element => {
            element.style.display = '';
        });
        return;
    }
    
    searchableElements.forEach(element => {
        const text = element.textContent.toLowerCase();
        const isMatch = text.includes(normalizedQuery);
        element.style.display = isMatch ? '' : 'none';
    });
}

// Gestion des modales
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Fermer les modales en cliquant à l'extérieur
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target.id);
    }
});

// Gestion des onglets
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.dataset.tab;
            
            // Désactiver tous les onglets
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Activer l'onglet sélectionné
            this.classList.add('active');
            const targetContent = document.getElementById(targetTab);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });
}

// Sauvegarde des préférences utilisateur
function saveUserPreference(key, value) {
    try {
        localStorage.setItem(`nsi_site_${key}`, JSON.stringify(value));
    } catch (error) {
        console.warn('Impossible de sauvegarder les préférences:', error);
    }
}

function getUserPreference(key, defaultValue = null) {
    try {
        const saved = localStorage.getItem(`nsi_site_${key}`);
        return saved ? JSON.parse(saved) : defaultValue;
    } catch (error) {
        console.warn('Impossible de charger les préférences:', error);
        return defaultValue;
    }
}

// Thème sombre/clair (optionnel)
function toggleTheme() {
    const currentTheme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.body.classList.toggle('dark-theme');
    saveUserPreference('theme', newTheme);
}

// Charger le thème sauvegardé
function loadSavedTheme() {
    const savedTheme = getUserPreference('theme', 'light');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
    }
}

// Utilitaires généraux
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Gestion des erreurs globales
window.addEventListener('error', function(event) {
    console.error('Erreur JavaScript:', event.error);
});

// Export des fonctions utiles
window.NSI = {
    filterExercises,
    openModal,
    closeModal,
    toggleTheme,
    saveUserPreference,
    getUserPreference
};