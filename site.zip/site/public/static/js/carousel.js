// Carrousel pour les cartes de cours et exercices
document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour initialiser tous les carrousels sur la page
    function initCarousels() {
        const carousels = document.querySelectorAll('.carousel-container');
        
        carousels.forEach(carousel => {
            const track = carousel.querySelector('.carousel-track');
            const cards = carousel.querySelectorAll('.carousel-card');
            const prevButton = carousel.querySelector('.carousel-prev');
            const nextButton = carousel.querySelector('.carousel-next');
            
            if (!track || !cards.length) return;
            
            let currentIndex = 0;
            let cardWidth = cards[0].offsetWidth + 20; // Largeur + gap
            let cardsPerView = getCardsPerView();
            
            // Fonction pour déterminer le nombre de cartes visibles
            function getCardsPerView() {
                const containerWidth = carousel.offsetWidth;
                if (containerWidth < 768) return 1;
                if (containerWidth < 1024) return 2;
                return 3;
            }
            
            // Fonction pour mettre à jour la position du carrousel
            function updateCarouselPosition() {
                track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
                updateButtonStates();
            }
            
            // Fonction pour mettre à jour l'état des boutons
            function updateButtonStates() {
                if (prevButton) {
                    prevButton.disabled = currentIndex === 0;
                    prevButton.style.opacity = currentIndex === 0 ? '0.5' : '1';
                }
                
                if (nextButton) {
                    const maxIndex = Math.max(0, cards.length - cardsPerView);
                    nextButton.disabled = currentIndex >= maxIndex;
                    nextButton.style.opacity = currentIndex >= maxIndex ? '0.5' : '1';
                }
            }
            
            // Gestionnaires d'événements pour les boutons
            if (prevButton) {
                prevButton.addEventListener('click', () => {
                    if (currentIndex > 0) {
                        currentIndex--;
                        updateCarouselPosition();
                    }
                });
            }
            
            if (nextButton) {
                nextButton.addEventListener('click', () => {
                    const maxIndex = Math.max(0, cards.length - cardsPerView);
                    if (currentIndex < maxIndex) {
                        currentIndex++;
                        updateCarouselPosition();
                    }
                });
            }
            
            // Réinitialiser en cas de redimensionnement
            window.addEventListener('resize', () => {
                cardWidth = cards[0].offsetWidth + 20;
                cardsPerView = getCardsPerView();
                
                // Ajuster l'index si nécessaire
                const maxIndex = Math.max(0, cards.length - cardsPerView);
                if (currentIndex > maxIndex) {
                    currentIndex = maxIndex;
                }
                
                updateCarouselPosition();
            });
            
            // Gestion du tactile/swipe
            let touchStartX = 0;
            let touchStartY = 0;
            let isScrolling = false;
            
            carousel.addEventListener('touchstart', function(e) {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
                isScrolling = false;
            });
            
            carousel.addEventListener('touchmove', function(e) {
                if (!touchStartX || !touchStartY) return;
                
                const touchEndX = e.touches[0].clientX;
                const touchEndY = e.touches[0].clientY;
                const diffX = touchStartX - touchEndX;
                const diffY = touchStartY - touchEndY;
                
                // Déterminer si c'est un scroll vertical ou horizontal
                if (Math.abs(diffY) > Math.abs(diffX)) {
                    isScrolling = true;
                    return;
                }
                
                if (!isScrolling && Math.abs(diffX) > 30) {
                    const maxIndex = Math.max(0, cards.length - cardsPerView);
                    
                    if (diffX > 0 && currentIndex < maxIndex) {
                        currentIndex++;
                    } else if (diffX < 0 && currentIndex > 0) {
                        currentIndex--;
                    }
                    
                    updateCarouselPosition();
                    touchStartX = null;
                    touchStartY = null;
                    e.preventDefault();
                }
            });
            
            carousel.addEventListener('touchend', function() {
                touchStartX = null;
                touchStartY = null;
                isScrolling = false;
            });
            
            // Navigation au clavier
            carousel.addEventListener('keydown', function(e) {
                if (e.key === 'ArrowLeft' && currentIndex > 0) {
                    currentIndex--;
                    updateCarouselPosition();
                    e.preventDefault();
                } else if (e.key === 'ArrowRight') {
                    const maxIndex = Math.max(0, cards.length - cardsPerView);
                    if (currentIndex < maxIndex) {
                        currentIndex++;
                        updateCarouselPosition();
                        e.preventDefault();
                    }
                }
            });
            
            // Initialisation
            updateCarouselPosition();
        });
    }
    
    // Fonction pour créer un carrousel automatiquement
    function createCarousel(container, items, options = {}) {
        const {
            itemsPerView = 3,
            gap = 20,
            showButtons = true,
            showDots = false,
            autoplay = false,
            autoplayDelay = 3000
        } = options;
        
        // Créer la structure HTML
        container.classList.add('carousel-container');
        container.innerHTML = `
            ${showButtons ? '<button class="carousel-btn carousel-prev"><i class="fas fa-chevron-left"></i></button>' : ''}
            <div class="carousel-track">
                ${items.map(item => `<div class="carousel-card">${item}</div>`).join('')}
            </div>
            ${showButtons ? '<button class="carousel-btn carousel-next"><i class="fas fa-chevron-right"></i></button>' : ''}
            ${showDots ? '<div class="carousel-dots"></div>' : ''}
        `;
        
        // Ajouter les styles CSS si nécessaire
        if (!document.querySelector('#carousel-styles')) {
            const styles = document.createElement('style');
            styles.id = 'carousel-styles';
            styles.textContent = `
                .carousel-container {
                    position: relative;
                    overflow: hidden;
                    padding: 0 40px;
                }
                
                .carousel-track {
                    display: flex;
                    gap: ${gap}px;
                    transition: transform 0.3s ease;
                }
                
                .carousel-card {
                    flex: 0 0 calc((100% - ${(itemsPerView - 1) * gap}px) / ${itemsPerView});
                    min-width: 0;
                }
                
                .carousel-btn {
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    background: var(--background-primary);
                    border: 1px solid var(--border-color);
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    z-index: 10;
                    transition: all 0.3s ease;
                    box-shadow: var(--shadow-light);
                }
                
                .carousel-btn:hover {
                    background: var(--primary-color);
                    color: var(--text-light);
                    box-shadow: var(--shadow-medium);
                }
                
                .carousel-btn:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
                
                .carousel-prev {
                    left: 0;
                }
                
                .carousel-next {
                    right: 0;
                }
                
                .carousel-dots {
                    display: flex;
                    justify-content: center;
                    gap: 8px;
                    margin-top: 20px;
                }
                
                .carousel-dot {
                    width: 10px;
                    height: 10px;
                    border-radius: 50%;
                    background: var(--border-color);
                    cursor: pointer;
                    transition: background 0.3s ease;
                }
                
                .carousel-dot.active {
                    background: var(--primary-color);
                }
                
                @media (max-width: 768px) {
                    .carousel-container {
                        padding: 0 30px;
                    }
                    
                    .carousel-card {
                        flex: 0 0 calc(100% - 20px);
                    }
                }
            `;
            document.head.appendChild(styles);
        }
        
        // Initialiser le carrousel
        initCarousels();
        
        // Autoplay si activé
        if (autoplay) {
            setInterval(() => {
                const nextBtn = container.querySelector('.carousel-next');
                if (nextBtn && !nextBtn.disabled) {
                    nextBtn.click();
                } else {
                    // Retour au début
                    const prevBtn = container.querySelector('.carousel-prev');
                    while (prevBtn && !prevBtn.disabled) {
                        prevBtn.click();
                    }
                }
            }, autoplayDelay);
        }
    }
    
    // Initialiser tous les carrousels existants
    initCarousels();
    
    // Exposer les fonctions globalement
    window.Carousel = {
        init: initCarousels,
        create: createCarousel
    };
});