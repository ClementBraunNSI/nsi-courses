# Script PowerShell pour lancer le site NSI
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "     LANCEMENT DU SITE NSI" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Vérification de Node.js
Write-Host "Verification de Node.js..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "Node.js version: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "ERREUR: Node.js n'est pas installe ou non accessible" -ForegroundColor Red
    Write-Host "Veuillez installer Node.js depuis https://nodejs.org" -ForegroundColor Red
    Read-Host "Appuyez sur Entree pour continuer"
    exit 1
}

Write-Host ""
Write-Host "Installation des dependances..." -ForegroundColor Yellow
try {
    npm install --no-optional
    Write-Host "Dependances installees avec succes!" -ForegroundColor Green
} catch {
    Write-Host "ERREUR: Echec de l'installation des dependances" -ForegroundColor Red
    Write-Host "Essayez de lancer en tant qu'administrateur" -ForegroundColor Red
    Read-Host "Appuyez sur Entree pour continuer"
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Demarrage du serveur sur http://localhost:3000" -ForegroundColor Green
Write-Host "Appuyez sur Ctrl+C pour arreter le serveur" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Démarrage du serveur
node server.js