const express = require('express');
const path = require('path');
const fs = require('fs-extra');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration du moteur de template EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware pour les fichiers statiques
app.use('/static', express.static(path.join(__dirname, 'public')));
app.use('/images', express.static(path.join(__dirname, '../docs/images')));

// Middleware pour parser les données
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Import des routes
const indexRoutes = require('./routes/index');
const courseRoutes = require('./routes/courses');
const exerciseRoutes = require('./routes/exercises');

// Utilisation des routes
app.use('/', indexRoutes);
app.use('/courses', courseRoutes);
app.use('/exercises', exerciseRoutes);

// Middleware de gestion d'erreur 404
app.use((req, res) => {
    res.status(404).render('error', {
        title: 'Page non trouvée',
        message: 'La page que vous cherchez n\'existe pas.',
        error: { status: 404 }
    });
});

// Middleware de gestion d'erreur générale
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', {
        title: 'Erreur serveur',
        message: 'Une erreur interne s\'est produite.',
        error: { status: 500 }
    });
});

// Démarrage du serveur
app.listen(PORT, () => {
    console.log(`🦊 Serveur NSI démarré sur http://localhost:${PORT}`);
    console.log(`📚 Site de cours de Clément Braun`);
});

module.exports = app;