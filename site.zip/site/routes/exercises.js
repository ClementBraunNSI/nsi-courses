const express = require('express');
const router = express.Router();
const exerciseController = require('../controllers/exerciseController');

// Liste de tous les exercices
router.get('/', exerciseController.index);

// Exercices d'un niveau spécifique
router.get('/:level', exerciseController.level);

// Contenu d'un exercice spécifique
router.get('/:level/:chapter/:file', exerciseController.exercise);

module.exports = router;