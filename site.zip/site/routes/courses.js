const express = require('express');
const router = express.Router();
const courseController = require('../controllers/courseController');

// Liste des niveaux
router.get('/', courseController.levels);

// Chapitres d'un niveau
router.get('/:level', courseController.chapters);

// Contenu d'un chapitre
router.get('/:level/:chapter', courseController.chapter);

// Contenu d'un fichier de cours
router.get('/:level/:chapter/:file', courseController.content);

module.exports = router;