const fs = require('fs-extra');
const path = require('path');
const marked = require('marked');
const matter = require('gray-matter');

class Course {
    constructor() {
        this.docsPath = path.join(__dirname, '../../docs');
    }

    // Récupère tous les niveaux disponibles
    async getLevels() {
        try {
            const levels = [
                {
                    id: 'seconde',
                    name: 'SNT - Seconde',
                    description: 'Sciences Numériques et Technologie : découverte des enjeux du numérique dans notre société',
                    image: '/images/fox_seconde.png',
                    path: 'seconde'
                },
                {
                    id: 'premiere',
                    name: 'NSI - Première',
                    description: 'Numérique et Sciences Informatiques : initiation à la programmation et aux concepts fondamentaux',
                    image: '/images/fox_premiere.png',
                    path: 'premiere'
                },
                {
                    id: 'terminale',
                    name: 'NSI - Terminale',
                    description: 'Approfondissement en informatique : structures de données, bases de données et projets avancés',
                    image: '/images/fox_terminale.png',
                    path: 'terminale'
                },
                {
                    id: 'chasse',
                    name: 'Chasse aux Ren\'arts',
                    description: 'Défi ludique et pédagogique pour mettre en pratique les compétences NSI de manière créative',
                    image: '/images/chasserenarts.png',
                    path: 'chasse_aux_renards'
                }
            ];
            return levels;
        } catch (error) {
            console.error('Erreur lors de la récupération des niveaux:', error);
            return [];
        }
    }

    // Récupère les chapitres d'un niveau
    async getChapters(level) {
        try {
            const levelPath = path.join(this.docsPath, level);
            if (!await fs.pathExists(levelPath)) {
                return [];
            }

            const items = await fs.readdir(levelPath);
            const chapters = [];

            for (const item of items) {
                const itemPath = path.join(levelPath, item);
                const stat = await fs.stat(itemPath);
                
                if (stat.isDirectory() && !item.startsWith('.')) {
                    // Nettoyer le nom du chapitre
                    let cleanName = item.replace(/^[IVX\d\-\s]+/, '').replace(/_/g, ' ');
                    if (cleanName.startsWith('- ')) {
                        cleanName = cleanName.substring(2);
                    }
                    
                    chapters.push({
                        id: item,
                        name: cleanName,
                        path: item,
                        fullPath: itemPath
                    });
                }
            }

            return chapters.sort((a, b) => a.id.localeCompare(b.id));
        } catch (error) {
            console.error(`Erreur lors de la récupération des chapitres pour ${level}:`, error);
            return [];
        }
    }

    // Récupère le contenu d'un cours
    async getCourseContent(level, chapter, file) {
        try {
            const filePath = path.join(this.docsPath, level, chapter, file);
            
            if (!await fs.pathExists(filePath)) {
                return null;
            }

            const content = await fs.readFile(filePath, 'utf8');
            
            // Si c'est un fichier markdown
            if (path.extname(filePath) === '.md') {
                const parsed = matter(content);
                return {
                    title: parsed.data.title || file.replace('.md', ''),
                    content: marked.parse(parsed.content),
                    metadata: parsed.data,
                    raw: content
                };
            }
            
            return {
                title: file,
                content: content,
                metadata: {},
                raw: content
            };
        } catch (error) {
            console.error(`Erreur lors de la lecture du fichier ${file}:`, error);
            return null;
        }
    }

    // Récupère les fichiers d'un chapitre
    async getChapterFiles(level, chapter) {
        try {
            const chapterPath = path.join(this.docsPath, level, chapter);
            
            if (!await fs.pathExists(chapterPath)) {
                return [];
            }

            const files = [];
            
            // Fonction récursive pour parcourir les dossiers
            const scanDirectory = async (dirPath, relativePath = '') => {
                const items = await fs.readdir(dirPath);
                
                for (const item of items) {
                    const itemPath = path.join(dirPath, item);
                    const stat = await fs.stat(itemPath);
                    const relativeItemPath = path.join(relativePath, item);
                    
                    if (stat.isDirectory()) {
                        await scanDirectory(itemPath, relativeItemPath);
                    } else if (item.endsWith('.md') || item.endsWith('.html')) {
                        files.push({
                            name: item,
                            path: relativeItemPath,
                            type: path.extname(item).substring(1),
                            fullPath: itemPath
                        });
                    }
                }
            };
            
            await scanDirectory(chapterPath);
            return files;
        } catch (error) {
            console.error(`Erreur lors de la récupération des fichiers pour ${level}/${chapter}:`, error);
            return [];
        }
    }
}

module.exports = new Course();