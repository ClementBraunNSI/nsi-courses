const Course = require('../models/Course');

class HomeController {
    // Page d'accueil
    async index(req, res) {
        try {
            const levels = await Course.getLevels();
            
            res.render('index', {
                title: 'NSI - Clément Braun',
                levels: levels,
                currentPage: 'home'
            });
        } catch (error) {
            console.error('Erreur dans homeController.index:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement de la page d\'accueil',
                error: error
            });
        }
    }

    // Page à propos
    async about(req, res) {
        try {
            res.render('about', {
                title: 'À propos - NSI Clément Braun',
                currentPage: 'about'
            });
        } catch (error) {
            console.error('Erreur dans homeController.about:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement de la page à propos',
                error: error
            });
        }
    }
}

module.exports = new HomeController();