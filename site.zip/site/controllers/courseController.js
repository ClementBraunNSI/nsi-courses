const Course = require('../models/Course');

class CourseController {
    // Liste des niveaux
    async levels(req, res) {
        try {
            const levels = await Course.getLevels();
            
            res.render('courses/levels', {
                title: 'Niveaux - NSI Clément Braun',
                levels: levels,
                currentPage: 'courses'
            });
        } catch (error) {
            console.error('Erreur dans courseController.levels:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement des niveaux',
                error: error
            });
        }
    }

    // Chapitres d'un niveau
    async chapters(req, res) {
        try {
            const { level } = req.params;
            const chapters = await Course.getChapters(level);
            const levels = await Course.getLevels();
            const currentLevel = levels.find(l => l.id === level);
            
            if (!currentLevel) {
                return res.status(404).render('error', {
                    title: 'Niveau non trouvé',
                    message: `Le niveau "${level}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            res.render('courses/chapters', {
                title: `${currentLevel.name} - Chapitres`,
                level: currentLevel,
                chapters: chapters,
                currentPage: 'courses'
            });
        } catch (error) {
            console.error('Erreur dans courseController.chapters:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement des chapitres',
                error: error
            });
        }
    }

    // Contenu d'un chapitre
    async chapter(req, res) {
        try {
            const { level, chapter } = req.params;
            const files = await Course.getChapterFiles(level, chapter);
            const levels = await Course.getLevels();
            const currentLevel = levels.find(l => l.id === level);
            
            if (!currentLevel) {
                return res.status(404).render('error', {
                    title: 'Niveau non trouvé',
                    message: `Le niveau "${level}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            // Nettoyer le nom du chapitre pour l'affichage
            let chapterName = chapter.replace(/^[IVX\d\-\s]+/, '').replace(/_/g, ' ');
            if (chapterName.startsWith('- ')) {
                chapterName = chapterName.substring(2);
            }
            
            res.render('courses/chapter', {
                title: `${chapterName} - ${currentLevel.name}`,
                level: currentLevel,
                chapter: {
                    id: chapter,
                    name: chapterName
                },
                files: files,
                currentPage: 'courses'
            });
        } catch (error) {
            console.error('Erreur dans courseController.chapter:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement du chapitre',
                error: error
            });
        }
    }

    // Contenu d'un fichier de cours
    async content(req, res) {
        try {
            const { level, chapter, file } = req.params;
            const content = await Course.getCourseContent(level, chapter, file);
            const levels = await Course.getLevels();
            const currentLevel = levels.find(l => l.id === level);
            
            if (!content) {
                return res.status(404).render('error', {
                    title: 'Fichier non trouvé',
                    message: `Le fichier "${file}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            if (!currentLevel) {
                return res.status(404).render('error', {
                    title: 'Niveau non trouvé',
                    message: `Le niveau "${level}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            // Nettoyer le nom du chapitre pour l'affichage
            let chapterName = chapter.replace(/^[IVX\d\-\s]+/, '').replace(/_/g, ' ');
            if (chapterName.startsWith('- ')) {
                chapterName = chapterName.substring(2);
            }
            
            res.render('courses/content', {
                title: `${content.title} - ${chapterName}`,
                level: currentLevel,
                chapter: {
                    id: chapter,
                    name: chapterName
                },
                content: content,
                currentPage: 'courses'
            });
        } catch (error) {
            console.error('Erreur dans courseController.content:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement du contenu',
                error: error
            });
        }
    }
}

module.exports = new CourseController();