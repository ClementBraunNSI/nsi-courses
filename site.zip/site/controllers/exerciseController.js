const Course = require('../models/Course');

class ExerciseController {
    // Liste des exercices par niveau
    async index(req, res) {
        try {
            const levels = await Course.getLevels();
            const exercisesByLevel = {};
            
            // Récupérer les exercices pour chaque niveau
            for (const level of levels) {
                if (level.id !== 'chasse') {
                    const chapters = await Course.getChapters(level.id);
                    const exercises = [];
                    
                    for (const chapter of chapters) {
                        const files = await Course.getChapterFiles(level.id, chapter.id);
                        const exerciseFiles = files.filter(file => 
                            file.name.toLowerCase().includes('exercice') || 
                            file.name.toLowerCase().includes('fiche') ||
                            file.path.toLowerCase().includes('exercice')
                        );
                        
                        if (exerciseFiles.length > 0) {
                            exercises.push({
                                chapter: chapter,
                                files: exerciseFiles
                            });
                        }
                    }
                    
                    exercisesByLevel[level.id] = {
                        level: level,
                        exercises: exercises
                    };
                }
            }
            
            res.render('exercises/index', {
                title: 'Exercices - NSI Clément Braun',
                exercisesByLevel: exercisesByLevel,
                currentPage: 'exercises'
            });
        } catch (error) {
            console.error('Erreur dans exerciseController.index:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement des exercices',
                error: error
            });
        }
    }

    // Exercices d'un niveau spécifique
    async level(req, res) {
        try {
            const { level } = req.params;
            const levels = await Course.getLevels();
            const currentLevel = levels.find(l => l.id === level);
            
            if (!currentLevel) {
                return res.status(404).render('error', {
                    title: 'Niveau non trouvé',
                    message: `Le niveau "${level}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            const chapters = await Course.getChapters(level);
            const exercises = [];
            
            for (const chapter of chapters) {
                const files = await Course.getChapterFiles(level, chapter.id);
                const exerciseFiles = files.filter(file => 
                    file.name.toLowerCase().includes('exercice') || 
                    file.name.toLowerCase().includes('fiche') ||
                    file.path.toLowerCase().includes('exercice')
                );
                
                if (exerciseFiles.length > 0) {
                    exercises.push({
                        chapter: chapter,
                        files: exerciseFiles
                    });
                }
            }
            
            res.render('exercises/level', {
                title: `Exercices ${currentLevel.name}`,
                level: currentLevel,
                exercises: exercises,
                currentPage: 'exercises'
            });
        } catch (error) {
            console.error('Erreur dans exerciseController.level:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement des exercices du niveau',
                error: error
            });
        }
    }

    // Contenu d'un exercice spécifique
    async exercise(req, res) {
        try {
            const { level, chapter, file } = req.params;
            const content = await Course.getCourseContent(level, chapter, file);
            const levels = await Course.getLevels();
            const currentLevel = levels.find(l => l.id === level);
            
            if (!content) {
                return res.status(404).render('error', {
                    title: 'Exercice non trouvé',
                    message: `L'exercice "${file}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            if (!currentLevel) {
                return res.status(404).render('error', {
                    title: 'Niveau non trouvé',
                    message: `Le niveau "${level}" n'existe pas.`,
                    error: { status: 404 }
                });
            }
            
            // Nettoyer le nom du chapitre pour l'affichage
            let chapterName = chapter.replace(/^[IVX\d\-\s]+/, '').replace(/_/g, ' ');
            if (chapterName.startsWith('- ')) {
                chapterName = chapterName.substring(2);
            }
            
            res.render('exercises/exercise', {
                title: `${content.title} - Exercice`,
                level: currentLevel,
                chapter: {
                    id: chapter,
                    name: chapterName
                },
                content: content,
                currentPage: 'exercises'
            });
        } catch (error) {
            console.error('Erreur dans exerciseController.exercise:', error);
            res.status(500).render('error', {
                title: 'Erreur',
                message: 'Erreur lors du chargement de l\'exercice',
                error: error
            });
        }
    }
}

module.exports = new ExerciseController();