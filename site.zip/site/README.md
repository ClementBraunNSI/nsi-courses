# Site NSI - Clément Braun

Site web développé avec Node.js, Express et EJS pour présenter les cours et exercices de NSI/SNT.

## Installation

1. Assurez-vous d'avoir Node.js installé sur votre système
2. Ouvrez un terminal dans le dossier `site/`
3. Installez les dépendances :
   ```bash
   npm install
   ```

## Démarrage

Pour démarrer le serveur de développement :
```bash
npm start
```

Ou pour le mode développement avec rechargement automatique :
```bash
npm run dev
```

Le site sera accessible à l'adresse : http://localhost:3000

## Structure du projet

```
site/
├── controllers/          # Contrôleurs MVC
│   ├── homeController.js
│   ├── courseController.js
│   └── exerciseController.js
├── models/              # Modèles de données
│   └── Course.js
├── routes/              # Routes Express
│   ├── index.js
│   ├── courses.js
│   └── exercises.js
├── views/               # Templates EJS
│   ├── layout.ejs
│   ├── index.ejs
│   ├── courses.ejs
│   ├── exercises.ejs
│   └── about.ejs
├── public/              # Fichiers statiques
│   ├── static/
│   │   ├── css/
│   │   └── js/
│   └── images/
├── server.js            # Serveur principal
├── package.json         # Configuration npm
└── README.md           # Ce fichier
```

## Fonctionnalités

### Architecture MVC
- **Modèles** : Gestion des données des cours et exercices
- **Vues** : Templates EJS avec layout responsive
- **Contrôleurs** : Logique métier pour chaque section

### Pages disponibles
- **Accueil** (`/`) : Présentation générale et navigation
- **Cours** (`/courses`) : Navigation par niveaux et chapitres
- **Exercices** (`/exercises`) : Collection d'exercices avec filtres
- **À propos** (`/about`) : Informations sur le projet

### Fonctionnalités techniques
- Design responsive adapté mobile/desktop
- Support des fichiers Markdown pour le contenu
- Carrousel interactif pour la navigation
- Filtrage et recherche des exercices
- Support MathJax pour les formules mathématiques
- Coloration syntaxique du code

## Personnalisation

### Ajout de contenu
1. Placez vos fichiers de cours dans `../docs/`
2. Organisez-les par niveau (seconde, premiere, terminale, etc.)
3. Le site détectera automatiquement la structure

### Modification du design
- CSS principal : `public/static/css/main.css`
- Composants : `public/static/css/components.css`
- JavaScript : `public/static/js/main.js`

### Configuration
Modifiez `server.js` pour :
- Changer le port (défaut: 3000)
- Ajouter des middlewares
- Configurer les routes

## Développement

### Scripts disponibles
- `npm start` : Démarre le serveur de production
- `npm run dev` : Démarre avec nodemon (rechargement auto)
- `npm test` : Lance les tests (à implémenter)

### Dépendances principales
- **express** : Framework web
- **ejs** : Moteur de templates
- **marked** : Parser Markdown
- **gray-matter** : Parser front matter
- **fs-extra** : Utilitaires système de fichiers

## Déploiement

1. Assurez-vous que tous les fichiers sont présents
2. Installez les dépendances de production :
   ```bash
   npm install --production
   ```
3. Démarrez le serveur :
   ```bash
   npm start
   ```

## Support

Pour toute question ou problème :
1. Vérifiez que Node.js est installé (`node --version`)
2. Vérifiez que npm fonctionne (`npm --version`)
3. Consultez les logs du serveur pour les erreurs

## Licence

Ce projet est développé pour l'enseignement de la NSI/SNT.
Tous droits réservés - Clément Braun