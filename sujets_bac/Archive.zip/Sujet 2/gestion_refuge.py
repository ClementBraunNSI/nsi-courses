import csv
# Le module csv est inclus ici, mais une lecture simple par ligne est aussi possible.

class Renard:
    """
    Classe représentant un renard dans le refuge.
    Attributs : identifiant, nom, poids, date_arrivee.
    À compléter (Question 1)
    """
    def __init__(self, identifiant:int, nom:str, poids:float, date_arrivee:str)-> None:
        # Q1.a : Compléter le constructeur
        self.id = identifiant
        self.nom = nom
        self.poids = poids
        self.date_arrivee = date_arrivee

    def __str__(self)->str:
        # Q1.b : Compléter la méthode d'affichage
        ""

class Refuge:
    """
    Classe représentant le refuge contenant la liste des renards.
    À compléter (Question 2)
    """
    def __init__(self, nom:int, adresse:str)->None:
        # Q2.a : Compléter le constructeur
        self.nom = ...
        self.adresse = ...
        self.renards = ...
        
    def recueillir(self, un_renard:Renard)->None:
        # Q2.b : Compléter la méthode d'ajout
        pass

    def lister_sous_poids(self)->list[Renard]:
        """
        Q4.a : Doit renvoyer une liste des Renards dont le poids est < 6.0 kg.
        """
        return [renard for renard in self.renards if renard.poids < 6]

    def pourcentage_sous_poids(self)->float:
        """
        Q4.b : Doit renvoyer le pourcentage des renards en sous-poids.
        """
        return len(self.lister_sous_poids()) / len(self.renards) * 100


def importer_donnees(nom_fichier:str, refuge:Refuge)->None:
    print(f"Tentative d'importation depuis {nom_fichier}...")
    with open(nom_fichier, 'r', encoding='utf-8') as f:
            lignes = csv.DictReader(f, delimiter=';')
            for ligne in lignes:
                renard = Renard((ligne['id']), ligne['nom'], (ligne['poids']), ligne['date_arrivee'])
                refuge.recueillir(renard)
